# Author: Hapsoro.
# Modified by Hendrik Molder, 2019

drawBarChart <- function (data, x_axis, y_axis, group_col, title = "", legend = group_col,
                          x_legend = x_axis, y_legend = y_axis) {
  library(ggplot2)
  result <- ggplot(data = data, aes_string(x = x_axis, y = y_axis, fill = group_col)) + geom_bar(colour = "black", stat = "identity",
                    position = position_dodge(), size = 0.3) + scale_fill_hue(name = legend) + xlab(x_legend) + ylab(y_legend) + ggtitle(title) + theme_bw()
  return(result)
}
