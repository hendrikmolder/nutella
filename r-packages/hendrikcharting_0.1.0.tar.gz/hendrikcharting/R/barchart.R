drawBarChart <- function(data, x = "averageSpeed", xlabel = "Hours", ylabel = "Average speed", title = "Average hourly speed", xnames = "hour", weathercol = "weatherCond") {
  library(dplyr)
  colours <- c()
  for (i in 1:length(data[[weathercol]])) {
    if (data[,weathercol][i]=="dry") {
      colours[i] <- "brown"
    } else {
      colours[i] <- "lightblue"
    }
  }

  barplot(height=data[[x]],
          main = title,
          xlab = xlabel,
          col=colours,
          names.arg = data[[xnames]],
          ylab = ylabel,
          beside=TRUE)
  legend("bottomright", c("dry", "wet"), fill=c("brown", "lightblue"))
}

